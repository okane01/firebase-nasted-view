import 'package:firedemo1/screeen/feed.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'notifier/places_Notifier.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<AllPlacesNotifier>(
          create: (ctx) => AllPlacesNotifier(),
        ),
      ],
      child: MaterialApp(
        title: 'Flutter Demo',
        theme: ThemeData(
          primarySwatch: Colors.amber,
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        home: Feed(),
      ),
    );
  }
}
