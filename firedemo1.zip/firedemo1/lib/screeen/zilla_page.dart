import 'package:firedemo1/notifier/places_Notifier.dart';
import 'package:firedemo1/services/services_api.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class ZillaPage extends StatefulWidget {
  final String id;
  ZillaPage({this.id});
  @override
  _ZillaPageState createState() => _ZillaPageState();
}

class _ZillaPageState extends State<ZillaPage> {
  @override
  void initState() {
    AllPlacesNotifier currentPageTitle =
        Provider.of<AllPlacesNotifier>(context, listen: false);
    getZilla(currentPageTitle);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    AllPlacesNotifier currentPageTitle =
        Provider.of<AllPlacesNotifier>(context);
    final zillaData = currentPageTitle.zilla.where((prod) {
      return prod.categories.contains(widget.id);
    }).toList();
    return Scaffold(
      appBar: AppBar(
        title: Text('Zilla Page Screen'),
      ),
      body: zillaData.length == 0
          ? Center(
              child: CircularProgressIndicator(),
            )
          : ListView.builder(
              itemBuilder: (ctx, i) => ListTile(
                    title: Text(
                      zillaData[i].name,
                    ),
                  ),
              itemCount: zillaData.length),
    );
  }
}
