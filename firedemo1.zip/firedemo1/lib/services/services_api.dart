import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firedemo1/model/country.dart';
import 'package:firedemo1/model/division.dart';
import 'package:firedemo1/model/zilla.dart';
import '../notifier/places_Notifier.dart';

getCountry(AllPlacesNotifier placesNotifier) async {
  QuerySnapshot snapshot =
      await Firestore.instance.collection('country').getDocuments();
  List<Country> _country = [];

  snapshot.documents.forEach((documents) {
    Country country = Country.fromMap(documents.data);
    _country.add(country);
  });
  placesNotifier.countryList = _country;
}

getDivision(AllPlacesNotifier divisionNotify) async {
  QuerySnapshot snapshot =
      await Firestore.instance.collection('division').getDocuments();
  List<Division> _divisionList = [];

  snapshot.documents.forEach((documents) {
    Division division = Division.fromMap(documents.data);
    _divisionList.add(division);
  });
  divisionNotify.divisionList = _divisionList;
}

getZilla(AllPlacesNotifier zillaNotify) async {
  QuerySnapshot snapshot =
      await Firestore.instance.collection('zilla').getDocuments();
  List<Zillas> _zillaList = [];

  snapshot.documents.forEach((documents) {
    Zillas zilla = Zillas.fromMap(documents.data);
    _zillaList.add(zilla);
  });
  zillaNotify.zilla = _zillaList;
}
