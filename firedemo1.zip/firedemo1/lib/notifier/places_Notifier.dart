import 'dart:collection';
import 'package:firedemo1/model/division.dart';
import 'package:firedemo1/model/food.dart';
import 'package:firedemo1/model/zilla.dart';
import 'package:flutter/foundation.dart';

import '../model/country.dart';

class AllPlacesNotifier with ChangeNotifier {
  List<Country> _countryList = [];
  Country _currentCountry;

  UnmodifiableListView<Country> get countryList =>
      UnmodifiableListView(_countryList);

  Country get currentCountry => _currentCountry;

  set countryList(List<Country> country) {
    _countryList = country;
    notifyListeners();
  }

  set currentCountry(Country country) {
    _currentCountry = country;
    notifyListeners();
  }

  List<Division> _divisionList = [];
  Division _currentDivision;

  UnmodifiableListView<Division> get divisionList =>
      UnmodifiableListView(_divisionList);

  Division get currentDivision => _currentDivision;

  set divisionList(List<Division> division) {
    _divisionList = division;
    notifyListeners();
  }

  set currentDivision(Division division) {
    currentDivision = division;
    notifyListeners();
  }

  List<Zillas> _zilla = [];
  Zillas _currentZilla;
  List<Zillas> get zilla => [..._zilla];
  Zillas get currentZilla => _currentZilla;

  set zilla(List<Zillas> zilla) {
    _zilla = zilla;
    notifyListeners();
  }

  set currentZilla(Zillas zilla) {
    _currentZilla = zilla;
    notifyListeners();
  }

  List<Food> _listFood = [];
  Food _currentFood;
  UnmodifiableListView<Food> get feedList => UnmodifiableListView(_listFood);
  Food get currentFeed => _currentFood;

  set feedList(List<Food> feed) {
    _listFood = feed;
    notifyListeners();
  }

  set currentFeed(Food feed) {
    _currentFood = feed;
    notifyListeners();
  }
}
