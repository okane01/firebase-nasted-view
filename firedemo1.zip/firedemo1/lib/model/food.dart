class Food {
  String id;
  String name;
  String imageUrl;
  String description;
  List subPlaces;
  Food.fromMap(Map<String, dynamic> data) {
    id = data['id'];
    name = data['name'];
    imageUrl = data['imageUrl'];
    subPlaces = data['ingridient'];
    description = data['description'];
  }
}
