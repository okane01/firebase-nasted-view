package com.example.firedemo1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
